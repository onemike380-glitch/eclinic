const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Appointment = require('../models/Appointment');

// Book appointment (patient)
router.post('/book', auth, async (req, res) => {
  const { doctorId, date } = req.body;
  try {
    const appointment = new Appointment({
      patient: req.user._id,
      doctor: doctorId,
      date
    });
    await appointment.save();
    res.json(appointment);
  } catch (err) {
    res.status(500).send('Server error');
  }
});

// Get my appointments (doctor or patient)
router.get('/my', auth, async (req, res) => {
  try {
    let query = req.user.role === 'doctor' ? { doctor: req.user._id } : { patient: req.user._id };
    const appointments = await Appointment.find(query).populate('patient doctor', 'name email role');
    res.json(appointments);
  } catch (err) {
    res.status(500).send('Server error');
  }
});

// Update appointment status (doctor)
router.patch('/:id/status', auth, async (req, res) => {
  if (req.user.role !== 'doctor') return res.status(403).json({ msg: 'Access denied' });
  const { status } = req.body;
  if (!['confirmed', 'rejected'].includes(status)) return res.status(400).json({ msg: 'Invalid status' });
  try {
    const appointment = await Appointment.findOneAndUpdate(
      { _id: req.params.id, doctor: req.user._id },
      { status },
      { new: true }
    );
    res.json(appointment);
  } catch (err) {
    res.status(500).send('Server error');
  }
});

module.exports = router;