// Get all doctors (for patient to choose)
router.get('/doctors', async (req, res) => {
  const doctors = await User.find({ role: 'doctor' }).select('name email');
  res.json(doctors);
});