const express = require('express');
const router = express.Router();
const auth = require('../middleware/auth');
const Message = require('../models/Message');

// Get messages for an appointment (doctor or patient)
router.get('/:appointmentId', auth, async (req, res) => {
  try {
    const messages = await Message.find({ appointment: req.params.appointmentId })
      .sort('timestamp')
      .populate('sender receiver', 'name role');
    res.json(messages);
  } catch (err) {
    res.status(500).send('Server error');
  }
});

// Save a new message
router.post('/', auth, async (req, res) => {
  const { receiverId, appointmentId, content } = req.body;
  try {
    const msg = new Message({
      sender: req.user._id,
      receiver: receiverId,
      appointment: appointmentId,
      content
    });
    await msg.save();
    res.json(msg);
  } catch (err) {
    res.status(500).send('Server error');
  }
});

module.exports = router;