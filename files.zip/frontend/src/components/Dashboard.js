function Dashboard({ user }) {
  // ...existing code
  return (
    <div className="bg-dashboard" style={{ minHeight: '100vh', padding: 30 }}>
      {/* ...dashboard content */}
    </div>
  );
}