function Register({ setUser }) {
  // ...existing code
  return (
    <div className="bg-register" style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
      <form onSubmit={handleSubmit} style={{ background: 'rgba(255,255,255,0.85)', padding: 30, borderRadius: 8 }}>
        {/* ...form fields */}
      </form>
    </div>
  );
}