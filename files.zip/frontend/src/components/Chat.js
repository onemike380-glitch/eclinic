function Chat({ user }) {
  // ...existing code
  return (
    <div className="bg-chat" style={{ minHeight: '100vh', padding: 30 }}>
      {/* ...chat content */}
    </div>
  );
}